# WordPress MySQL database migration
#
# Generated: Monday 27. June 2022 06:14 UTC
# Hostname: mysql
# Database: `shape`
# URL: //shape.nativesstaging.com.au
# Path: /var/www/html
# Tables: wp_commentmeta, wp_comments, wp_frm_fields, wp_frm_forms, wp_frm_item_metas, wp_frm_items, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wpfm_backup, wp_yoast_indexable, wp_yoast_indexable_hierarchy, wp_yoast_migrations, wp_yoast_primary_term, wp_yoast_seo_links
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, frm_form_actions, frm_styles, nav_menu_item, page, post, property_rental, property_sale, wp_global_styles
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-01-09 21:59:27', '2022-01-09 21:59:27', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_frm_fields`
#

DROP TABLE IF EXISTS `wp_frm_fields`;


#
# Table structure of table `wp_frm_fields`
#

CREATE TABLE `wp_frm_fields` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `field_key` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `description` longtext COLLATE utf8mb4_unicode_520_ci,
  `type` text COLLATE utf8mb4_unicode_520_ci,
  `default_value` longtext COLLATE utf8mb4_unicode_520_ci,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `field_order` int DEFAULT '0',
  `required` int DEFAULT NULL,
  `field_options` longtext COLLATE utf8mb4_unicode_520_ci,
  `form_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `field_key` (`field_key`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_frm_fields`
#
INSERT INTO `wp_frm_fields` ( `id`, `field_key`, `name`, `description`, `type`, `default_value`, `options`, `field_order`, `required`, `field_options`, `form_id`, `created_at`) VALUES
(1, 'qh4icy', '', '', 'text', '', '', 2, 1, 'a:16:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:27:"This field cannot be blank.";s:18:"required_indicator";s:0:"";s:7:"invalid";s:15:"Name is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:18:"frm_first frm_half";s:11:"custom_html";s:508:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\r\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\r\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\r\n    </label>\r\n    [input]\r\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\r\n    [if error]<div class="frm_error" id="frm_error_field_[key]">[error]</div>[/if error]\r\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:10:"First Name";s:10:"in_section";i:0;}', 1, '2022-01-09 22:01:02'),
(2, 'ocfup1', '', '', 'text', '', '', 3, 1, 'a:16:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:27:"This field cannot be blank.";s:18:"required_indicator";s:0:"";s:7:"invalid";s:15:"Last is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:8:"frm_half";s:11:"custom_html";s:508:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\r\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\r\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\r\n    </label>\r\n    [input]\r\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\r\n    [if error]<div class="frm_error" id="frm_error_field_[key]">[error]</div>[/if error]\r\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:9:"Last Name";s:10:"in_section";i:0;}', 1, '2022-01-09 22:01:02'),
(3, '29yf4d', '', '', 'email', '', '', 5, 1, 'a:16:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:27:"This field cannot be blank.";s:18:"required_indicator";s:0:"";s:7:"invalid";s:34:"Please enter a valid email address";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:14:"frm6 frm_first";s:11:"custom_html";s:508:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\r\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\r\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\r\n    </label>\r\n    [input]\r\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\r\n    [if error]<div class="frm_error" id="frm_error_field_[key]">[error]</div>[/if error]\r\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:5:"Email";s:10:"in_section";i:0;}', 1, '2022-01-09 22:01:02'),
(4, 'e6lis6', '', '', 'text', '', '', 6, 1, 'a:16:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:27:"This field cannot be blank.";s:18:"required_indicator";s:0:"";s:7:"invalid";s:18:"Subject is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:4:"frm6";s:11:"custom_html";s:508:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\r\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\r\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\r\n    </label>\r\n    [input]\r\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\r\n    [if error]<div class="frm_error" id="frm_error_field_[key]">[error]</div>[/if error]\r\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:16:"Property Address";s:10:"in_section";i:0;}', 1, '2022-01-09 22:01:02'),
(5, '9jv0r1', '', '', 'textarea', '', '', 8, 1, 'a:16:{s:4:"size";s:0:"";s:3:"max";s:1:"5";s:5:"label";s:0:"";s:5:"blank";s:27:"This field cannot be blank.";s:18:"required_indicator";s:0:"";s:7:"invalid";s:0:"";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:8:"frm_full";s:11:"custom_html";s:508:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\r\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\r\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\r\n    </label>\r\n    [input]\r\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\r\n    [if error]<div class="frm_error" id="frm_error_field_[key]">[error]</div>[/if error]\r\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:7:"Message";s:10:"in_section";i:0;}', 1, '2022-01-09 22:01:02'),
(6, 'xvt5z', '', '', 'text', '', '', 2, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:14:"frm6 frm_first";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:9:"Firstname";}', 2, '2022-02-25 06:22:56'),
(7, '361op', '', '', 'text', '', '', 5, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:14:"frm6 frm_first";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:5:"Email";}', 2, '2022-02-25 06:23:01'),
(8, '9k1fl', '', '', 'text', '', '', 8, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:0:"";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:12:"Enquiry Type";}', 2, '2022-02-25 06:23:08'),
(9, 'ea49j', '', '', 'text', '', '', 3, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:4:"frm6";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:8:"Lastname";}', 2, '2022-02-25 06:23:10'),
(10, 'kcvax', '', '', 'text', '', '', 6, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:4:"frm6";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:8:"Postcode";}', 2, '2022-02-25 06:23:14'),
(11, 'nd3ss', '', '', 'textarea', '', '', 10, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:1:"5";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:0:"";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:0:"";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:7:"Message";}', 2, '2022-02-25 06:23:59'),
(12, 'rg989', 'What’s your enquiry about?', '', 'checkbox', '', 'a:4:{i:0;a:2:{s:5:"label";s:24:"Scheduling an inspection";s:5:"value";s:8:"Option 1";}i:1;a:2:{s:5:"label";s:19:"Pricing Information";s:5:"value";s:8:"Option 2";}i:2;a:2:{s:5:"label";s:12:"Rates & fees";s:5:"value";s:10:"New Option";}i:3;a:2:{s:5:"label";s:18:"Similar properties";s:5:"value";s:10:"New Option";}}', 2, 0, 'a:16:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:0:"";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:15:"frm12 frm_first";s:11:"custom_html";s:586:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\r\n    <div  id="field_[key]_label" class="frm_primary_label">[field_name]\r\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\r\n    </div>\r\n    <div class="frm_opt_container" aria-labelledby="field_[key]_label" role="group">[input]</div>\r\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\r\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\r\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:0:"";s:5:"align";s:5:"block";}', 3, '2022-03-11 07:02:43'),
(14, '1cf10', '', '', 'text', '', '', 6, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:14:"frm6 frm_first";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:9:"Full Name";}', 3, '2022-03-11 07:18:46'),
(15, 'kg936', '', '', 'text', '', '', 10, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:4:"frm6";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:27:"What are you looking to do?";}', 3, '2022-03-11 07:18:52'),
(16, '1p3pl', '', '', 'text', '', '', 9, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:14:"frm6 frm_first";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:12:"Phone Number";}', 3, '2022-03-11 07:18:53'),
(17, 'krz74', '', '', 'text', '', '', 7, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:15:"Text is invalid";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:4:"frm6";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:13:"Email Address";}', 3, '2022-03-11 07:18:58'),
(18, 'ogaq4', '', '', 'textarea', '', '', 4, 0, 'a:15:{s:4:"size";s:0:"";s:3:"max";s:1:"5";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:0:"";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:0:"";s:11:"custom_html";s:514:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <label for="field_[key]" id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </label>\n    [input]\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:7:"Message";}', 3, '2022-03-11 07:19:56'),
(19, 'znsu', 'Do you have finance pre-approval?', '', 'radio', '', 'a:3:{i:0;a:2:{s:5:"label";s:3:"Yes";s:5:"value";s:3:"Yes";}i:1;a:2:{s:5:"label";s:2:"No";s:5:"value";s:2:"No";}i:2;a:2:{s:5:"label";s:14:"Rather Not Say";s:5:"value";s:14:"Rather Not Say";}}', 12, 0, 'a:16:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:0:"";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:0:"";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:0:"";s:11:"custom_html";s:579:"<div id="frm_field_[id]_container" class="frm_form_field form-field [required_class][error_class]">\n    <div  id="field_[key]_label" class="frm_primary_label">[field_name]\n        <span class="frm_required" aria-hidden="true">[required_label]</span>\n    </div>\n    <div class="frm_opt_container" aria-labelledby="field_[key]_label" role="group">[input]</div>\n    [if description]<div class="frm_description" id="frm_desc_field_[key]">[description]</div>[/if description]\n    [if error]<div class="frm_error" role="alert" id="frm_error_field_[key]">[error]</div>[/if error]\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:0:"";s:5:"align";s:5:"block";}', 3, '2022-03-11 07:20:19'),
(20, '5u7j7', 'reCAPTCHA', '', 'captcha', '', '', 9, 0, 'a:17:{s:4:"size";s:0:"";s:3:"max";s:0:"";s:5:"label";s:4:"none";s:5:"blank";s:0:"";s:18:"required_indicator";s:1:"*";s:7:"invalid";s:40:"The reCAPTCHA was not entered correctly,";s:14:"separate_value";i:0;s:14:"clear_on_focus";i:0;s:7:"classes";s:11:"frm-captcha";s:11:"custom_html";s:545:"<div id=\\"frm_field_[id]_container\\" class=\\"frm_form_field form-field [required_class][error_class]\\">\r\n    <label for=\\"field_[key]\\" id=\\"field_[key]_label\\" class=\\"frm_primary_label\\">[field_name]\r\n        <span class=\\"frm_required\\" aria-hidden=\\"true\\">[required_label]</span>\r\n    </label>\r\n    [input]\r\n    [if description]<div class=\\"frm_description\\" id=\\"frm_desc_field_[key]\\">[description]</div>[/if description]\r\n    [if error]<div class=\\"frm_error\\" role=\\"alert\\" id=\\"frm_error_field_[key]\\">[error]</div>[/if error]\r\n</div>";s:6:"minnum";i:1;s:6:"maxnum";i:10;s:4:"step";i:1;s:6:"format";s:0:"";s:11:"placeholder";s:0:"";s:12:"captcha_size";s:6:"normal";s:13:"captcha_theme";s:5:"light";}', 1, '2022-04-28 06:36:33') ;

#
# End of data contents of table `wp_frm_fields`
# --------------------------------------------------------



#
# Delete any existing table `wp_frm_forms`
#

DROP TABLE IF EXISTS `wp_frm_forms`;


#
# Table structure of table `wp_frm_forms`
#

CREATE TABLE `wp_frm_forms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `form_key` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `parent_form_id` int DEFAULT '0',
  `logged_in` tinyint(1) DEFAULT NULL,
  `editable` tinyint(1) DEFAULT NULL,
  `is_template` tinyint(1) DEFAULT '0',
  `default_template` tinyint(1) DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `form_key` (`form_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_frm_forms`
#
INSERT INTO `wp_frm_forms` ( `id`, `form_key`, `name`, `description`, `parent_form_id`, `logged_in`, `editable`, `is_template`, `default_template`, `status`, `options`, `created_at`) VALUES
(1, 'contact-form', 'Contact Us', '<p>We would like to hear from you. Please send us a message by filling out the form below and we will get back with you shortly.</p>\r\n', 0, 0, 0, 0, 0, 'published', 'a:19:{s:14:"success_action";s:7:"message";s:11:"success_url";s:0:"";s:15:"success_page_id";s:0:"";s:8:"honeypot";s:5:"basic";s:11:"js_validate";s:1:"1";s:11:"success_msg";s:54:"Your responses were successfully submitted. Thank you!";s:12:"custom_style";s:1:"1";s:12:"submit_value";s:6:"Submit";s:10:"form_class";s:0:"";s:11:"before_html";s:232:"<legend class=\\"frm_screen_reader\\">[form_name]</legend>\r\n[if form_name]<h3 class=\\"frm_form_title\\">[form_name]</h3>[/if form_name]\r\n[if form_description]<div class=\\"frm_description\\">[form_description]</div>[/if form_description]";s:10:"after_html";s:0:"";s:11:"submit_html";s:418:"<div class=\\"frm_submit\\">\r\n[if back_button]<button type=\\"submit\\" name=\\"frm_prev_page\\" formnovalidate=\\"formnovalidate\\" class=\\"frm_prev_page\\" [back_hook]>[back_label]</button>[/if back_button]\r\n<button class=\\"frm_button_submit\\" type=\\"submit\\"  [button_action]>[button_label]</button>\r\n[if save_draft]<a href=\\"#\\" tabindex=\\"0\\" class=\\"frm_save_draft\\" [draft_hook]>[draft_label]</a>[/if save_draft]\r\n</div>";s:9:"show_form";i:0;s:7:"akismet";s:0:"";s:8:"antispam";i:0;s:7:"no_save";i:0;s:9:"ajax_load";i:0;s:10:"show_title";i:0;s:16:"show_description";i:0;}', '2022-01-09 22:01:02'),
(2, 'contactform', 'Contact Form', '', 0, 0, 0, 0, 0, 'published', 'a:17:{s:8:"antispam";i:1;s:12:"submit_value";s:6:"Submit";s:14:"success_action";s:7:"message";s:11:"success_msg";s:54:"Your responses were successfully submitted. Thank you!";s:9:"show_form";i:0;s:7:"akismet";s:0:"";s:8:"honeypot";s:5:"basic";s:7:"no_save";i:0;s:9:"ajax_load";i:0;s:11:"js_validate";i:0;s:10:"form_class";s:0:"";s:12:"custom_style";i:1;s:11:"before_html";s:224:"<legend class="frm_screen_reader">[form_name]</legend>\n[if form_name]<h3 class="frm_form_title">[form_name]</h3>[/if form_name]\n[if form_description]<div class="frm_description">[form_description]</div>[/if form_description]";s:10:"after_html";s:0:"";s:11:"submit_html";s:394:"<div class="frm_submit">\n[if back_button]<button type="submit" name="frm_prev_page" formnovalidate="formnovalidate" class="frm_prev_page" [back_hook]>[back_label]</button>[/if back_button]\n<button class="frm_button_submit" type="submit"  [button_action]>[button_label]</button>\n[if save_draft]<a href="#" tabindex="0" class="frm_save_draft" [draft_hook]>[draft_label]</a>[/if save_draft]\n</div>";s:10:"show_title";i:0;s:16:"show_description";i:0;}', '2022-02-25 06:22:52'),
(3, 'formregister', 'Form Register', '', 0, 0, 0, 0, 0, 'published', 'a:19:{s:14:"success_action";s:7:"message";s:11:"success_url";s:0:"";s:15:"success_page_id";s:0:"";s:8:"honeypot";s:5:"basic";s:8:"antispam";s:1:"1";s:11:"success_msg";s:54:"Your responses were successfully submitted. Thank you!";s:12:"custom_style";s:1:"1";s:12:"submit_value";s:12:"Send Inquiry";s:10:"form_class";s:0:"";s:11:"before_html";s:232:"<legend class=\\"frm_screen_reader\\">[form_name]</legend>\r\n[if form_name]<h3 class=\\"frm_form_title\\">[form_name]</h3>[/if form_name]\r\n[if form_description]<div class=\\"frm_description\\">[form_description]</div>[/if form_description]";s:10:"after_html";s:0:"";s:11:"submit_html";s:418:"<div class=\\"frm_submit\\">\r\n[if back_button]<button type=\\"submit\\" name=\\"frm_prev_page\\" formnovalidate=\\"formnovalidate\\" class=\\"frm_prev_page\\" [back_hook]>[back_label]</button>[/if back_button]\r\n<button class=\\"frm_button_submit\\" type=\\"submit\\"  [button_action]>[button_label]</button>\r\n[if save_draft]<a href=\\"#\\" tabindex=\\"0\\" class=\\"frm_save_draft\\" [draft_hook]>[draft_label]</a>[/if save_draft]\r\n</div>";s:9:"show_form";i:0;s:7:"akismet";s:0:"";s:7:"no_save";i:0;s:9:"ajax_load";i:0;s:11:"js_validate";i:0;s:10:"show_title";i:0;s:16:"show_description";i:0;}', '2022-03-11 07:02:19') ;

#
# End of data contents of table `wp_frm_forms`
# --------------------------------------------------------



#
# Delete any existing table `wp_frm_item_metas`
#

DROP TABLE IF EXISTS `wp_frm_item_metas`;


#
# Table structure of table `wp_frm_item_metas`
#

CREATE TABLE `wp_frm_item_metas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  `field_id` bigint NOT NULL,
  `item_id` bigint NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_frm_item_metas`
#
INSERT INTO `wp_frm_item_metas` ( `id`, `meta_value`, `field_id`, `item_id`, `created_at`) VALUES
(1, 'a:2:{i:0;s:24:"Scheduling an inspection";i:1;s:12:"Rates & fees";}', 12, 6, '2022-03-21 09:07:52'),
(2, 'Yes', 19, 6, '2022-03-21 09:07:52'),
(3, 'a:2:{i:0;s:24:"Scheduling an inspection";i:1;s:12:"Rates & fees";}', 12, 7, '2022-03-21 09:10:21'),
(4, 'Yes', 19, 7, '2022-03-21 09:10:21'),
(5, 'a:4:{i:0;s:24:"Scheduling an inspection";i:1;s:19:"Pricing Information";i:2;s:12:"Rates & fees";i:3;s:18:"Similar properties";}', 12, 18, '2022-04-01 05:58:38'),
(6, 'No', 19, 18, '2022-04-01 05:58:38') ;

#
# End of data contents of table `wp_frm_item_metas`
# --------------------------------------------------------

